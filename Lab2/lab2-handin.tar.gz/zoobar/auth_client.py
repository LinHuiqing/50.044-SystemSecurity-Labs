from debug import *
from zoodb import *
import rpclib

sockname = "/authsvc/sock"

def login(username, password):
    data = {}
    data['username'] = username
    data['password'] = password
    sock = rpclib.client_connect(sockname)
    return sock.call('login', **data)

def register(username, password):
    data = {}
    data['username'] = username
    data['password'] = password
    sock = rpclib.client_connect(sockname)
    return sock.call('register', **data)

def check_token(username, token):
    data = {}
    data['username'] = username
    data['token'] = token
    sock = rpclib.client_connect(sockname)
    return sock.call('check_token', **data)
