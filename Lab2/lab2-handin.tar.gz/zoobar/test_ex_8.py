import rpclib

sockname = "/banksvc/sock"
sock = rpclib.client_connect(sockname)

def transfer_with_token(fake_token):
  data = {}
  data['sender'] = "user1"
  data['recipient'] = "user2"
  data['zoobars'] = 10
  data['sender_input_token'] = fake_token
  return sock.call('transfer', **data)

if __name__ == "__main__":
  transfer_with_token("fake_token")