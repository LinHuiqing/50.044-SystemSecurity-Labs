#!/usr/bin/env python2

import rpclib
import sys
from debug import *

class EchoRpcServer(rpclib.RpcServer):
    def rpc_echo(self, s):
        from test_ex_8 import transfer_with_token
        transfer_with_token(s)
        return 'You said: %s' % s

(_, dummy_zookld_fd, sockpath) = sys.argv

s = EchoRpcServer()
s.run_sockpath_fork(sockpath)

