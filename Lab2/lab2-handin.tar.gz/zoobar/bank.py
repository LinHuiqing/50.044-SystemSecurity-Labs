from zoodb import *
from debug import *

import time

def transfer(sender, recipient, zoobars, sender_input_token):
    bank_db = bank_setup()
    sender_bank = bank_db.query(Bank).get(sender)
    recipient_bank = bank_db.query(Bank).get(recipient)

    sender_balance = sender_bank.zoobars - zoobars
    recipient_balance = recipient_bank.zoobars + zoobars

    if sender_balance < 0 or recipient_balance < 0:
        raise ValueError()

    sender_bank.zoobars = sender_balance
    recipient_bank.zoobars = recipient_balance
    bank_db.commit()

    transfer = Transfer()
    transfer.sender = sender
    transfer.recipient = recipient
    transfer.amount = zoobars
    transfer.time = time.asctime()

    transferdb = transfer_setup()
    transferdb.add(transfer)
    transferdb.commit()

def balance(username):
    bank_db = bank_setup()
    bank_user = bank_db.query(Bank).get(username)
    return bank_user.zoobars

def get_log(username):
    db = transfer_setup()
    return db.query(Transfer).filter(or_(Transfer.sender==username,
                                         Transfer.recipient==username))

def new_account(username):
    bank_db = bank_setup()
    newbank = Bank()
    newbank.username = username
    bank_db.add(newbank)
    bank_db.commit()