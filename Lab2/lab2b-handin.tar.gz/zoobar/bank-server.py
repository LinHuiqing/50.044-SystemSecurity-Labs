#!/usr/bin/env python2

import rpclib
import sys
import bank
from debug import *
from zoodb import cred_setup
import auth_client

class BankRpcServer(rpclib.RpcServer):
    def rpc_transfer(self, sender, recipient, zoobars, sender_input_token):
        if not auth_client.check_token(sender, sender_input_token):
            raise ValueError("Invalid token. IMPOSTER!!")
        return bank.transfer(sender, recipient, zoobars, sender_input_token)
    
    def rpc_balance(self, username):
        return bank.balance(username)

    def rpc_get_log(self, username):
        logs = []
        for row in bank.get_log(username):
            row_dict = row.__dict__
            row_dict.pop('_sa_instance_state', None)
            logs.append(row_dict)
        return logs
    
    def rpc_new_account(self, username):
        return bank.new_account(username)

(_, dummy_zookld_fd, sockpath) = sys.argv

s = BankRpcServer()
s.run_sockpath_fork(sockpath)
