from debug import *
from zoodb import *
import rpclib

sockname = "/banksvc/sock"
sock = rpclib.client_connect(sockname)

def transfer(sender, recipient, zoobars, sender_input_token):
    data = {}
    data['sender'] = sender
    data['recipient'] = recipient
    data['zoobars'] = zoobars
    data['sender_input_token'] = sender_input_token
    return sock.call('transfer', **data)

def balance(username):
    data = {}
    data['username'] = username
    return sock.call('balance', **data)

def get_log(username):
    data = {}
    data['username'] = username
    return sock.call('get_log', **data)

def new_account(username):
    data = {}
    data['username'] = username
    return sock.call('new_account', **data)
    