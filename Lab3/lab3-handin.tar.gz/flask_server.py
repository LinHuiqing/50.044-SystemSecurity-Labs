#!/usr/bin/env python2

from flask import Flask
from flask import request
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from urllib.parse import unquote

app = Flask(__name__)

@app.route('/', methods=['GET'])
def email_server():
    arg1 = request.args.get('to', None)
    arg2 = request.args.get('payload', None)

    if arg1 is None or arg2 is None:
        return 'Error: Missing parameters'
    else:
        payload = unquote(arg2)
        print("to={}".format(arg1))
        print("payload={}".format(payload))
        message = Mail(
            from_email='huiqing_lin@mymail.sutd.edu.sg',
            to_emails=arg1,
            subject='System Security Lab 3 Ex 13',
            html_content=payload)

        sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
        response = sg.send(message)
        print(response.status_code, response.body, response.headers)
        return 'to=' + arg1 + ', payload=' + payload

app.run(host='127.0.0.1', port=8000, debug=True)
